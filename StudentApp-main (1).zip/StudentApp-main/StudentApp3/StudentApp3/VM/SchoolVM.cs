﻿namespace StudentApp3.VM
{
    public class SchoolVM
    {
        public string Name { get; set; } = "";
        public string Address { get; set; } = "";
        public int YearEstablished { get; set; }
    }
}

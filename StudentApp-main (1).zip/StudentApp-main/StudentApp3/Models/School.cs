﻿namespace StudentApp3.Models
{
    public class School : Baseclass
    {
        public string Name { get; set; } = "";
        public string Address { get; set; } = "";
        public int YearEstablished { get; set; }
    }
}
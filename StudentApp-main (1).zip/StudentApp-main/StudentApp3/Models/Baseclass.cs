﻿namespace StudentApp3.Models
{
    public class Baseclass
    {
        public int Id { get; set; }
        public DateTime DateCreated { get; set; }
        public DateTime? DateUpdated { get; set; }

    }
}

